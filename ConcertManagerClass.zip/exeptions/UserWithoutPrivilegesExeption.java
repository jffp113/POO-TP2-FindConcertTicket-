package exeptions;

@SuppressWarnings("serial")
public class UserWithoutPrivilegesExeption extends Exception {

}
