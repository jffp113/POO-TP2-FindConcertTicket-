package exeptions;

@SuppressWarnings("serial")
public class PerformerDoesNotExistExeption extends Exception {

}
