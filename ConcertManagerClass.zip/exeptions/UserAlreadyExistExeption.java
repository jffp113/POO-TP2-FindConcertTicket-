package exeptions;

@SuppressWarnings("serial")
public class UserAlreadyExistExeption extends Exception {

}
