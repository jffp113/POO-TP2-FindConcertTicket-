package exeptions;

@SuppressWarnings("serial")
public class UserPasswordMismatchExeption extends Exception {

}
