package exeptions;

@SuppressWarnings("serial")
public class UserLoggedInExeption extends Exception {

}
