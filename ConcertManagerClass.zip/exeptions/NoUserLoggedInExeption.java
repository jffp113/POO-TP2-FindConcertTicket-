package exeptions;

@SuppressWarnings("serial")
public class NoUserLoggedInExeption extends Exception {

}
