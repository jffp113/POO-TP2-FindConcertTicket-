package exeptions;

@SuppressWarnings("serial")
public class UserDoesNotExistExeption extends Exception {

}
