package exeptions;

@SuppressWarnings("serial")
public class NoTicketsExeption extends Exception {

}
