package exeptions;

@SuppressWarnings("serial")
public class ShowAlreadyExistsExeption extends Exception {

}
