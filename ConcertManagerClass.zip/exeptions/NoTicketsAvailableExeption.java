package exeptions;

@SuppressWarnings("serial")
public class NoTicketsAvailableExeption extends Exception {

}
