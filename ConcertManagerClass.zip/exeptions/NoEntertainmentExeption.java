package exeptions;

@SuppressWarnings("serial")
public class NoEntertainmentExeption extends Exception {

}
