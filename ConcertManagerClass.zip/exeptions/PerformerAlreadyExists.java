package exeptions;

@SuppressWarnings("serial")
public class PerformerAlreadyExists extends Exception {

}
